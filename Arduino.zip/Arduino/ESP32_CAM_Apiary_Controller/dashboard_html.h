/*
  ============================================================
  PART 1B — IntelliHive Web Dashboard (PROGMEM HTML/CSS/JS)
  ============================================================
  This file contains ONLY the dashboard front-end, stored as a
  PROGMEM string so it can be served by the standard WebServer
  (server.send(200, "text/html", DASHBOARD_HTML)) from Part 1A.

  Usage in Part 1A (not rewritten here):
    #include "dashboard_html.h"

    void handleRoot() {
      server.send_P(200, "text/html", DASHBOARD_HTML);
    }

  Expected JSON response from a "/status" endpoint, polled every
  second via fetch(). Field names below must be matched by the
  backend handler:

  {
    "temperature": 28.5,
    "humidity": 55.2,
    "servoStatus": "OPEN",
    "wifiStatus": "Connected",
    "cleanliness": 87,
    "hiveWeight": 24.3,
    "honeyFill": 62
  }
  ============================================================
*/

#ifndef DASHBOARD_HTML_H
#define DASHBOARD_HTML_H

#include <Arduino.h>

const char DASHBOARD_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IntelliHive Dashboard</title>
<style>
  :root {
    --blue-primary: #1e6fd9;
    --blue-dark: #0d47a1;
    --blue-light: #eaf2fd;
    --blue-accent: #4fa3ff;
    --white: #ffffff;
    --gray-text: #5a6a7a;
    --dark-text: #1b2733;
    --card-radius: 16px;
    --shadow: 0 4px 16px rgba(13, 71, 161, 0.08);
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Roboto, Arial, sans-serif;
  }

  body {
    background: linear-gradient(180deg, var(--blue-light) 0%, var(--white) 100%);
    color: var(--dark-text);
    min-height: 100vh;
    padding-bottom: 40px;
  }

  /* ===================== HEADER ===================== */
  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: var(--white);
    padding: 16px 24px;
    box-shadow: var(--shadow);
    position: sticky;
    top: 0;
    z-index: 10;
    flex-wrap: wrap;
  }

  .logo-wrap {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .logo-icon {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--blue-primary), var(--blue-accent));
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(30, 111, 217, 0.4);
    flex-shrink: 0;
  }

  .logo-icon svg {
    width: 24px;
    height: 24px;
    fill: var(--white);
  }

  .logo-text {
    display: flex;
    flex-direction: column;
    line-height: 1.1;
  }

  .logo-text .title {
    font-size: 20px;
    font-weight: 700;
    color: var(--blue-dark);
    letter-spacing: 0.3px;
  }

  .logo-text .subtitle {
    font-size: 12px;
    color: var(--gray-text);
    font-weight: 500;
  }

  .connection-pill {
    display: flex;
    align-items: center;
    gap: 8px;
    background: var(--blue-light);
    padding: 6px 14px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 600;
    color: var(--blue-dark);
  }

  .dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: #2ecc71;
    box-shadow: 0 0 0 3px rgba(46, 204, 113, 0.25);
  }

  .dot.offline {
    background: #e74c3c;
    box-shadow: 0 0 0 3px rgba(231, 76, 60, 0.25);
  }

  /* ===================== LAYOUT ===================== */
  main {
    max-width: 1100px;
    margin: 0 auto;
    padding: 24px 20px;
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 18px;
  }

  /* ===================== CARDS ===================== */
  .card {
    background: var(--white);
    border-radius: var(--card-radius);
    box-shadow: var(--shadow);
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    border: 1px solid rgba(30, 111, 217, 0.06);
  }

  .card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(13, 71, 161, 0.14);
  }

  .card-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .card-label {
    font-size: 13px;
    font-weight: 600;
    color: var(--gray-text);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .card-icon {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    background: var(--blue-light);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
  }

  .card-value {
    font-size: 32px;
    font-weight: 700;
    color: var(--blue-dark);
  }

  .card-value span.unit {
    font-size: 16px;
    font-weight: 500;
    color: var(--gray-text);
    margin-left: 2px;
  }

  .card-sub {
    font-size: 12px;
    color: var(--gray-text);
  }

  .status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 12px;
    border-radius: 999px;
    font-size: 14px;
    font-weight: 700;
    width: fit-content;
  }

  .status-open {
    background: rgba(46, 204, 113, 0.12);
    color: #1e8449;
  }

  .status-closed {
    background: rgba(231, 76, 60, 0.12);
    color: #c0392b;
  }

  .status-connected {
    background: rgba(46, 204, 113, 0.12);
    color: #1e8449;
  }

  .status-disconnected {
    background: rgba(231, 76, 60, 0.12);
    color: #c0392b;
  }

  /* ===================== PROGRESS BARS ===================== */
  .progress-track {
    width: 100%;
    height: 10px;
    background: var(--blue-light);
    border-radius: 999px;
    overflow: hidden;
    margin-top: 4px;
  }

  .progress-fill {
    height: 100%;
    border-radius: 999px;
    background: linear-gradient(90deg, var(--blue-primary), var(--blue-accent));
    transition: width 0.5s ease;
  }

  .progress-fill.honey {
    background: linear-gradient(90deg, #f1a208, #f6c453);
  }

  .progress-fill.clean {
    background: linear-gradient(90deg, #1e6fd9, #37c9b1);
  }

  /* ===================== FOOTER ===================== */
  footer {
    text-align: center;
    font-size: 12px;
    color: var(--gray-text);
    margin-top: 30px;
    padding: 0 20px;
  }

  /* ===================== RESPONSIVE ===================== */
  @media (max-width: 480px) {
    .logo-text .title { font-size: 17px; }
    .card-value { font-size: 26px; }
    header { padding: 12px 16px; }
    main { padding: 16px 12px; }
  }

  @media (min-width: 1024px) {
    .grid {
      grid-template-columns: repeat(4, 1fr);
    }
  }
</style>
</head>
<body>

  <header>
    <div class="logo-wrap">
      <div class="logo-icon">
        <svg viewBox="0 0 24 24"><path d="M12 2C9 2 6.5 4 6.5 7c0 1.7.9 3.1 2.1 4.1C7 12.4 6 14.4 6 16.6 6 19.6 8.7 22 12 22s6-2.4 6-5.4c0-2.2-1-4.2-2.6-5.5 1.2-1 2.1-2.4 2.1-4.1C17.5 4 15 2 12 2zm0 2c1.9 0 3.5 1.2 3.5 3s-1.6 3-3.5 3-3.5-1.2-3.5-3 1.6-3 3.5-3zm0 14c-2.2 0-4-1.5-4-3.4 0-1.8 1.2-3.3 3-3.8v-.1c.3.1.7.1 1 .1s.7 0 1-.1v.1c1.8.5 3 2 3 3.8 0 1.9-1.8 3.4-4 3.4z"/></svg>
      </div>
      <div class="logo-text">
        <span class="title">IntelliHive</span>
        <span class="subtitle">AIoT Smart Apiculture</span>
      </div>
    </div>
    <div class="connection-pill">
      <span class="dot" id="connDot"></span>
      <span id="connText">Connecting...</span>
    </div>
  </header>

  <main>
    <div class="grid">

      <!-- Temperature Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Temperature</span>
          <div class="card-icon">🌡️</div>
        </div>
        <div class="card-value"><span id="tempValue">--</span><span class="unit">°C</span></div>
        <div class="card-sub">Hive internal temperature</div>
      </div>

      <!-- Humidity Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Humidity</span>
          <div class="card-icon">💧</div>
        </div>
        <div class="card-value"><span id="humValue">--</span><span class="unit">%</span></div>
        <div class="card-sub">Relative humidity level</div>
      </div>

      <!-- Servo Status Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Queen Excluder</span>
          <div class="card-icon">⚙️</div>
        </div>
        <div id="servoBadge" class="status-badge status-open">OPEN</div>
        <div class="card-sub">Servo gate status</div>
      </div>

      <!-- WiFi Status Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Wi-Fi Status</span>
          <div class="card-icon">📶</div>
        </div>
        <div id="wifiBadge" class="status-badge status-connected">Connected</div>
        <div class="card-sub" id="wifiSub">Signal stable</div>
      </div>

      <!-- Cleanliness Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Cleanliness</span>
          <div class="card-icon">🧹</div>
        </div>
        <div class="card-value"><span id="cleanValue">--</span><span class="unit">%</span></div>
        <div class="progress-track"><div class="progress-fill clean" id="cleanBar" style="width:0%"></div></div>
      </div>

      <!-- Hive Weight Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Hive Weight</span>
          <div class="card-icon">⚖️</div>
        </div>
        <div class="card-value"><span id="weightValue">--</span><span class="unit">kg</span></div>
        <div class="card-sub">Simulated load reading</div>
      </div>

      <!-- Honey Fill Card -->
      <div class="card">
        <div class="card-head">
          <span class="card-label">Honey Fill Level</span>
          <div class="card-icon">🍯</div>
        </div>
        <div class="card-value"><span id="honeyValue">--</span><span class="unit">%</span></div>
        <div class="progress-track"><div class="progress-fill honey" id="honeyBar" style="width:0%"></div></div>
      </div>

    </div>

    <footer>
      IntelliHive &copy; 2026 — AI-Powered Smart Queen Excluder System
    </footer>
  </main>

<script>
  // Polling interval in milliseconds (1 second = live updates)
  const POLL_INTERVAL_MS = 1000;

  const el = {
    connDot: document.getElementById('connDot'),
    connText: document.getElementById('connText'),
    temp: document.getElementById('tempValue'),
    hum: document.getElementById('humValue'),
    servoBadge: document.getElementById('servoBadge'),
    wifiBadge: document.getElementById('wifiBadge'),
    wifiSub: document.getElementById('wifiSub'),
    clean: document.getElementById('cleanValue'),
    cleanBar: document.getElementById('cleanBar'),
    weight: document.getElementById('weightValue'),
    honey: document.getElementById('honeyValue'),
    honeyBar: document.getElementById('honeyBar')
  };

  // Update the servo badge style based on state
  function setServoBadge(state) {
    el.servoBadge.textContent = state;
    el.servoBadge.className = 'status-badge ' +
      (state === 'OPEN' ? 'status-open' : 'status-closed');
  }

  // Update the WiFi badge style based on state
  function setWifiBadge(connected) {
    el.wifiBadge.textContent = connected ? 'Connected' : 'Disconnected';
    el.wifiBadge.className = 'status-badge ' +
      (connected ? 'status-connected' : 'status-disconnected');
    el.wifiSub.textContent = connected ? 'Signal stable' : 'No network link';
  }

  // Update the header connection indicator
  function setConnIndicator(online) {
    el.connDot.classList.toggle('offline', !online);
    el.connText.textContent = online ? 'Live' : 'Offline';
  }

  // Fetch latest sensor/status data from the ESP32 WebServer
  async function fetchStatus() {
    try {
      const res = await fetch('/status', { cache: 'no-store' });
      if (!res.ok) throw new Error('Bad response');
      const data = await res.json();

      el.temp.textContent   = (typeof data.temperature === 'number') ? data.temperature.toFixed(1) : '--';
      el.hum.textContent    = (typeof data.humidity === 'number') ? data.humidity.toFixed(1) : '--';
      el.clean.textContent  = (typeof data.cleanliness === 'number') ? Math.round(data.cleanliness) : '--';
      el.weight.textContent = (typeof data.hiveWeight === 'number') ? data.hiveWeight.toFixed(1) : '--';
      el.honey.textContent  = (typeof data.honeyFill === 'number') ? Math.round(data.honeyFill) : '--';

      el.cleanBar.style.width = (data.cleanliness || 0) + '%';
      el.honeyBar.style.width = (data.honeyFill || 0) + '%';

      setServoBadge(data.servoStatus === 'OPEN' ? 'OPEN' : 'CLOSED');
      setWifiBadge(data.wifiStatus === 'Connected');

      setConnIndicator(true);
    } catch (err) {
      // Mark UI as offline if the ESP32 stops responding
      setConnIndicator(false);
    }
  }

  // Start polling immediately, then every POLL_INTERVAL_MS
  fetchStatus();
  setInterval(fetchStatus, POLL_INTERVAL_MS);
</script>

</body>
</html>
)rawliteral";

#endif // DASHBOARD_HTML_H
